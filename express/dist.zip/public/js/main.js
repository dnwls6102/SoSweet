'use strict';

let isChannelReady = false;     // 채널이 통신할 준비가 됐는지 확인
let isInitiator = false;        // 방을 생성한 Peer인지 확인
let isStarted = false;          // Stream이 시작했는지
let lastAnswer = null;
let isOffered = false;
let localStream;                // 로컬 Stream을 설정
let pc;                         // 통신 객체?
let remoteStream;               // 원격 Stream을 설정

// PeerConnection 구성요소 세팅. ICE 서버를 설정한다.
let pcConfig = {
  'iceServers': [{
    'urls': 'stun:stun.l.google.com:19302'
  }]
};

/////////////////////////////////////////////

// 소켓 연결 시도
let socket = io.connect('http://localhost:4000',{path:'/api/match'});
// let socket = io.connect();

// 대화방 생성한 클라이언트에게 생성자격 부여
socket.on('created', () => {
  isInitiator = true;
});

// 채널이 통신 가능 상태로 변경
socket.on('joined', () => {
  isChannelReady = true;

  if (isInitiator) {
    socket.emit('message', 'change state');
  }
});

////////////////////////////////////////////////

// 서버에 메세지 송신
const sendMessage = (message) => {
  console.log('Client sending message: ', message);
  socket.emit('message', message);
}

////////////////////////////////////////////////////

let localVideo = document.querySelector('#localVideo');     // 로컬 비디오 스트림을 담을 객체
let remoteVideo = document.querySelector('#remoteVideo');   // 원격 비디오 스트림을 담을 객체

// stream 객체 가져오기 및 등록
// 생성 클라이언트면 연결 시도
const gotStream = (stream) => {
    console.log('Adding local stream.');
    localStream = stream;
    localVideo.srcObject = stream;
    if (isChannelReady) {
        sendMessage('got user media');
    }
    // if (isInitiator) {
    //   maybeStart();
    // }
}

// WebRTC 인풋 디바이스 스트림 가져오기 및 연결 시작
navigator.mediaDevices.getUserMedia({
    audio: true,
    video: {
        width: { ideal: 640 },
        height: { ideal: 480 },
        frameRate: { ideal: 30, max: 60 }
    }
})
 .then(gotStream)
 .catch((e) => {
     alert('getUserMedia() error: ' + e.name);
});

// 윈도우 창 종료 전 bye 메세지 전송
window.onbeforeunload = () => {
  sendMessage('bye');
};

/////////////////////////////////////////////////////////

// ICE 후보를 감지하고, 원격 피어에 전달한다
const handleIceCandidate = (event) => {
    console.log('icecandidate event: ', event);
    if (event.candidate) { // 현재 ICE 후보 정보가 있다면
        // 시그널링 서버를 통해 원격 피어로 전송
        sendMessage({
            type: 'candidate',
            label: event.candidate.sdpMLineIndex,
            id: event.candidate.sdpMid,
            candidate: event.candidate.candidate
        });
    } else {
        console.log('End of candidates.');
    }
}

// Offer 생성 에러 핸들러
const handleCreateOfferError = (event) => {
    console.log('createOffer() error: ', event);
}

// local 설정 및 메세지 전송
const setLocalAndSendMessage = (sessionDescription) => {
    pc.setLocalDescription(sessionDescription);
    console.log('setLocalAndSendMessage sending message', sessionDescription);
    sendMessage(sessionDescription);
}

// 세션 생성 에러 핸들러
const onCreateSessionDescriptionError = (error) => {
    trace('Failed to create session description: ' + error.toString());
}

// peer에게 offer 전달
const doCall = () => {
    console.log('Sending offer to peer');
    pc.createOffer(setLocalAndSendMessage, handleCreateOfferError);
}

// peer에게 offer의 응답 전달
const doAnswer = () => {
    console.log('Sending answer to peer.');
    pc.createAnswer().then(
        setLocalAndSendMessage,
        onCreateSessionDescriptionError
    );
}

// TURN 서버로 응답
const requestTurn = (turnURL) => {
    let turnExists = false;
    // PeerConnection 설정 중에 중계 서버(TRUN)이 있는지 확인
    for (let i in pcConfig.iceServers) {
        if (pcConfig.iceServers[i].urls.substr(0, 5) === 'turn:') {
            turnExists = true;
            break;
        }
    }
    // 없으면 URL로 TURN 서버를 요청해서 설정에 새로 추가
    if (!turnExists) {
        console.log('Getting TURN server from ', turnURL);
        // No TURN server. Get one from computeengineondemand.appspot.com:
        let xhr = new XMLHttpRequest();
        // turnURL에서 응답이 오면 실행될 메서드
        xhr.onreadystatechange = () => {
            if (xhr.readyState === 4 && xhr.status === 200) {
                let turnServer = JSON.parse(xhr.responseText);
                console.log('Got TURN server: ', turnServer);
                pcConfig.iceServers.push({
                    'urls': 'turn:' + turnServer.username + '@' + turnServer.turn,
                    'credential': turnServer.password
                });
            }
        };
        // GET 방식으로 실제로 요청
        xhr.open('GET', turnURL, true);
        xhr.send();
    }
}

// localhost 외의 요청이 있으면
// TURN 서버 요청
if (location.hostname !== 'localhost') {
    requestTurn(
        'https://computeengineondemand.appspot.com/turn?username=41784574&key=4080218913'
    );
}

// 원격 피어에서 추가된 미디어 스트림 처리
const handleRemoteStreamAdded = (event) => {
    // 원격 피어의 미디어 스트림을 전역 변수와
    // 비디오 오브젝트의 소스로 추가
    console.log('Remote stream added.');
    remoteStream = event.stream;
    remoteVideo.srcObject = remoteStream;
}

// 원격 피어에서 추가된 미디어 스트림 제거 처리
// 제거 됐다고 표시하고 끝
const handleRemoteStreamRemoved = (event) => {
    console.log('Remote stream removed. Event: ', event);
}

// PeerConnection을 종료하고, 해당 객체를 null로 만들어
// GC가 메모리 처리할 수 있도록 한다.
const stop = () => {
    isStarted = false;
    pc.close();
    pc = null;
}

// 통화 종료 시 사용
// PeerConnection을 종료한다.
const hangup = () => {
    console.log('Hanging up.');
    stop();
    sendMessage('bye');
}

// bye 메세지를 수신한 모든 소켓 객체들은 통화를 종료한다.
const handleRemoteHangup = () => {
    console.log('Session terminated.');
    stop();
    isInitiator = false;
}
  
// This client receives a message
socket.on('message', (message) => {
    // 클라이언트가 보낸 메세지는 서버를 통해
    // 다른 클라이언트들에게 전송된다
    console.log('Client received message:', message);
    if (message === 'got user media') {                     // 이 메세지를 받으면 통신 시도
        maybeStart();
    } else if (message.type === 'offer' && !isInitiator) {                  // 메세지 타입이 offer면 PC 객체에 offer을 등록하고 연결 시도 및 응답
        if (isOffered) return;
        isOffered = true;
        if (!isInitiator && !isStarted) {
            maybeStart();
        }
        pc.setRemoteDescription(new RTCSessionDescription(message));
        doAnswer();
    } else if (message.type === 'answer' && isStarted) {    // 메세지 타입이 응답이면 PC 객체에 응답을 등록하고 연결 시도
        if (JSON.stringify(message) === lastAnswer) {
            console.log('Duplicate answer ignored.');
            return;
        }
        lastAnswer = JSON.stringify(message);
        if (pc.signalingState === 'stable' && message.type === 'answer') {
            console.error("Invalid state: cannot set answer in stable state");
        } else {
            pc.setRemoteDescription(new RTCSessionDescription(message))
                .then(() => console.log('Remote description set successfully'))
                .catch(error => console.error('Error setting remote description:', error));
        }        
    } else if (message.type === 'candidate' && isStarted) { // 메세지 타입이 지원자면 메세지를 기반으로 새로운 네트워크 경로를 등록
        let candidate = new RTCIceCandidate({
            sdpMLineIndex: message.label,
            candidate: message.candidate
        });
        pc.addIceCandidate(candidate);
    } else if (message === 'bye' && isStarted) {            // 메세지 타입이 bye고 실행 중이면, 연결 종료 수행
        handleRemoteHangup();
    }
});

// WebRTC의 PeerConnection API 사용
const createPeerConnection = () => {
    try {
        pc = new RTCPeerConnection(null);
        // PeerConnection 메서드의 함수를 지정
        pc.onicecandidate = handleIceCandidate;         // ICE 후보 처리
        pc.onaddstream = handleRemoteStreamAdded;       // 원격 피어에서 추가된 미디어 스트림 처리
        pc.onremovestream = handleRemoteStreamRemoved;  // 원격 피어에서 제거된 미디어 스트림 처리
        console.log('Created RTCPeerConnnection');
    } catch (e) {
        console.log('Failed to create PeerConnection, exception: ' + e.message);
        alert('Cannot create RTCPeerConnection object.');
        return;
  }
}

// 통신 시도 함수
const maybeStart = () => {
    console.log('>>>>>>> maybeStart() ');
    // 통신 중이 아니고, 로컬 스트림 장비가 있고, 통신 준비된 상황이면 연결 시도
    // console.log(isStarted, '\n',localStream, '\n',isChannelReady)
    if (!isStarted && typeof localStream !== 'undefined' && isChannelReady) {
        console.log('>>>>>> creating peer connection');
        createPeerConnection();         // PeerConnection 객체 생성
        pc.addStream(localStream);      // 생성한 pc 객체에 로컬 stream 객체 등록
        isStarted = true;               // 통신 실행으로 상태 변경
        console.log('isInitiator: ', isInitiator);
        if (isInitiator) {              // 생성 클라이언트면 통신 시작
            doCall();
        }
    }
}
