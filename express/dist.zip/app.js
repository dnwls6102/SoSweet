"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config(); // .env 파일 로드
const app = (0, express_1.default)();
// CORS 설정
app.use((0, cors_1.default)({
    origin: process.env.CLIENT_URL, // 허용할 클라이언트 도메인
    methods: ['GET', 'POST', 'PUT', 'DELETE'], // 허용할 HTTP 메서드
    credentials: true // 쿠키 허용
}));
// JSON 파싱 미들웨어
app.use(express_1.default.json());
// 간단한 라우터 추가
app.get('/', (req, res) => {
    res.send('소스윗 백엔드 서버 실행 중입니당');
});
exports.default = app;
